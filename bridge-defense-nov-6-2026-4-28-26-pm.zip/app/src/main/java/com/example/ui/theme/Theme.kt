package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BridgeArcadeColorScheme = darkColorScheme(
  primary = BridgeSkyBlue,
  onPrimary = Color.White,
  secondary = BridgeAmberGold,
  onSecondary = Color.Black,
  tertiary = BridgeGrassGreen,
  background = BridgeDarkSlate,
  surface = BridgeSurfaceSlate,
  onBackground = Color.White,
  onSurface = Color.White
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = BridgeArcadeColorScheme,
    typography = Typography,
    content = content
  )
}
