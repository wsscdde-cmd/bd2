package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppScreen
import com.example.model.BridgeGameUiState
import com.example.model.GameMode
import com.example.model.GameStatus
import com.example.model.Lane
import com.example.ui.canvas.BridgeWorldCanvas
import com.example.viewmodel.BridgeGameViewModel

@Composable
fun BridgeGameScreen(
  uiState: BridgeGameUiState,
  viewModel: BridgeGameViewModel,
  modifier: Modifier = Modifier
) {
  val achievements = viewModel.getAchievements()
  val unclaimedCount = achievements.count { it.isCompleted && !it.isClaimed }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
  ) {
    if (uiState.currentScreen == AppScreen.MAIN_MENU) {
      MainMenuScreen(
        uiState = uiState,
        unclaimedAchievementsCount = unclaimedCount,
        onStartEndless = { viewModel.startNewRun(GameMode.ENDLESS) },
        onStartCampaign = { viewModel.startNewRun(GameMode.CAMPAIGN) },
        onOpenPermanentUpgrades = { viewModel.setShowArmory(true) },
        onOpenStatsAndAchievements = { viewModel.setShowStats(true) },
        onOpenCompendium = { viewModel.setShowCompendium(true) },
        onOpenSettings = { viewModel.setShowSettings(true) }
      )
    } else {
      // BackHandler in gameplay pauses or returns to Main Menu
      BackHandler {
        if (uiState.status == GameStatus.PLAYING) {
          viewModel.togglePause()
        } else {
          viewModel.openMainMenu()
        }
      }

      // 1. Full-Screen 3-Lane Bridge World Canvas
      BridgeWorldCanvas(
        uiState = uiState,
        onPlayerMove = { normX -> viewModel.setPlayerHorizontalPosition(normX) },
        modifier = Modifier.fillMaxSize()
      )

      // 2. Top Banner & Left/Right Circular HUD Buttons
      TopBridgeHud(
        uiState = uiState,
        unclaimedAchievementsCount = unclaimedCount,
        onOpenMainMenu = { viewModel.openMainMenu() },
        onTogglePause = { viewModel.togglePause() },
        onOpenArmory = { viewModel.setShowArmory(true) },
        onOpenStats = { viewModel.setShowStats(true) },
        onOpenCompendium = { viewModel.setShowCompendium(true) },
        onToggleSpeed = { viewModel.toggleGameSpeed() },
        onToggleAutoPilot = { viewModel.toggleAutoPilot() },
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 10.dp, vertical = 6.dp)
      )

      // 3. Bottom Quick Lane Switcher & Bright Green Base Health Bar
      BottomBridgeHud(
        uiState = uiState,
        onSnapToLane = { lane -> viewModel.snapToLane(lane) },
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .navigationBarsPadding()
          .padding(horizontal = 12.dp, vertical = 8.dp)
      )

      // 4. Gameplay Pause / Victory / Defeat Overlays
      if (!uiState.showArmorySheet && !uiState.showStatsSheet && !uiState.showCompendiumSheet && !uiState.showSettingsSheet) {
        if (uiState.status == GameStatus.PAUSED) {
          PauseDialogOverlay(
            uiState = uiState,
            onResume = { viewModel.togglePause() },
            onRestart = { viewModel.retryCurrentWave() },
            onOpenArmory = { viewModel.setShowArmory(true) },
            onReturnToMainMenu = { viewModel.openMainMenu() }
          )
        } else if (uiState.status == GameStatus.WAVE_VICTORY) {
          WaveResultOverlay(
            isVictory = true,
            uiState = uiState,
            onPrimaryAction = { viewModel.advanceToNextWave() },
            onOpenArmory = { viewModel.setShowArmory(true) },
            onReturnToMainMenu = { viewModel.openMainMenu() }
          )
        } else if (uiState.status == GameStatus.GAME_OVER) {
          WaveResultOverlay(
            isVictory = false,
            uiState = uiState,
            onPrimaryAction = { viewModel.retryCurrentWave() },
            onOpenArmory = { viewModel.setShowArmory(true) },
            onReturnToMainMenu = { viewModel.openMainMenu() }
          )
        }
      }
    }

    // Shared Modal Sheets accessible from BOTH Main Menu and Gameplay
    if (uiState.showArmorySheet) {
      ArmoryAndSettingsOverlay(
        uiState = uiState,
        onBuyUpgrade = { viewModel.buyPermanentUpgrade(it) },
        onDismiss = { viewModel.setShowArmory(false) }
      )
    } else if (uiState.showStatsSheet) {
      StatsAndAchievementsOverlay(
        stats = uiState.playerStats,
        achievements = achievements,
        onClaimAchievement = { viewModel.claimAchievement(it) },
        onDismiss = { viewModel.setShowStats(false) }
      )
    } else if (uiState.showCompendiumSheet) {
      CompendiumOverlay(
        onDismiss = { viewModel.setShowCompendium(false) }
      )
    } else if (uiState.showSettingsSheet) {
      SettingsModalOverlay(
        uiState = uiState,
        onToggleSound = { viewModel.toggleSound() },
        onToggleHaptics = { viewModel.toggleHaptics() },
        onToggleSpeed = { viewModel.toggleGameSpeed() },
        onDismiss = { viewModel.setShowSettings(false) }
      )
    }
  }
}

@Composable
private fun TopBridgeHud(
  uiState: BridgeGameUiState,
  unclaimedAchievementsCount: Int,
  onOpenMainMenu: () -> Unit,
  onTogglePause: () -> Unit,
  onOpenArmory: () -> Unit,
  onOpenStats: () -> Unit,
  onOpenCompendium: () -> Unit,
  onToggleSpeed: () -> Unit,
  onToggleAutoPilot: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(modifier = modifier) {
    // Left Column of Round Translucent Buttons (Main Menu, Pause, Permanent Upgrades, Achievements)
    Column(
      modifier = Modifier.align(Alignment.TopStart),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      HudCircleIconButton(
        icon = Icons.Default.Home,
        contentDescription = "В главное меню",
        testTag = "hud_home_button",
        onClick = onOpenMainMenu
      )
      HudCircleIconButton(
        icon = if (uiState.status == GameStatus.PAUSED) Icons.Default.PlayArrow else Icons.Default.Pause,
        contentDescription = "Пауза",
        testTag = "hud_pause_button",
        onClick = onTogglePause
      )
      HudCircleIconButton(
        icon = Icons.Default.AutoAwesome,
        contentDescription = "Вечные улучшения",
        badgeText = "${uiState.permanentUpgrades.crystals}💎",
        testTag = "hud_armory_button",
        onClick = onOpenArmory
      )
      HudCircleIconButton(
        icon = Icons.Default.EmojiEvents,
        contentDescription = "Статистика и достижения",
        badgeText = if (unclaimedAchievementsCount > 0) "+$unclaimedAchievementsCount" else null,
        isActive = unclaimedAchievementsCount > 0,
        testTag = "hud_stats_button",
        onClick = onOpenStats
      )
    }

    // Center Banner Notification & Dual Currency Stats Pill
    Column(
      modifier = Modifier
        .align(Alignment.TopCenter)
        .padding(horizontal = 54.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Surface(
        color = Color(0xCF0F172A),
        shape = RoundedCornerShape(50),
        modifier = Modifier.border(1.5.dp, Color(0xFFFACC15), RoundedCornerShape(50))
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = if (uiState.gameMode == GameMode.ENDLESS) {
              "🔥 Угроза ${uiState.endlessThreatLevel}"
            } else {
              "Волна ${uiState.waveNumber}"
            },
            color = Color(0xFF4ADE80),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp
          )
          Text(
            text = "⚔ ${uiState.bulletDamage}",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
          )
          Text(
            text = "🪙 ${uiState.permanentUpgrades.gold}",
            color = Color(0xFFFACC15),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp
          )
          Text(
            text = "💎 ${uiState.permanentUpgrades.crystals}",
            color = Color(0xFF38BDF8),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      val subtitleBanner = if (uiState.gameMode == GameMode.ENDLESS) {
        val mins = (uiState.endlessElapsedSec / 60f).toInt()
        val secs = (uiState.endlessElapsedSec % 60f).toInt()
        "Бесконечный Режим (%02d:%02d) • Убито: %d".format(mins, secs, uiState.zombiesKilledInRun)
      } else {
        "Кампания: Волна ${uiState.waveNumber} • Убито: ${uiState.zombiesKilledInRun}"
      }

      Text(
        text = subtitleBanner,
        style = TextStyle(
          color = Color.White,
          fontSize = 13.sp,
          fontWeight = FontWeight.ExtraBold,
          shadow = Shadow(
            color = Color.Black,
            blurRadius = 6f
          )
        ),
        textAlign = TextAlign.Center
      )
    }

    // Right Column of Round Translucent Buttons (Compendium, Speed 1x/1.5x, AutoPilot)
    Column(
      modifier = Modifier.align(Alignment.TopEnd),
      verticalArrangement = Arrangement.spacedBy(8.dp),
      horizontalAlignment = Alignment.End
    ) {
      HudCircleIconButton(
        icon = Icons.Default.Visibility,
        contentDescription = "Бестиарий",
        testTag = "hud_compendium_button",
        onClick = onOpenCompendium
      )
      HudCircleIconButton(
        icon = Icons.Default.Speed,
        contentDescription = "Скорость игры",
        badgeText = if (uiState.gameSpeedMultiplier > 1.2f) "1.5x" else "1x",
        isActive = uiState.gameSpeedMultiplier > 1.2f,
        testTag = "hud_speed_button",
        onClick = onToggleSpeed
      )
      HudCircleIconButton(
        icon = Icons.Default.AutoMode,
        contentDescription = "Авто-наводка отряда",
        badgeText = if (uiState.autoPilotEnabled) "АВТО" else null,
        isActive = uiState.autoPilotEnabled,
        testTag = "hud_autopilot_button",
        onClick = onToggleAutoPilot
      )
    }
  }
}

@Composable
private fun HudCircleIconButton(
  icon: ImageVector,
  contentDescription: String,
  testTag: String,
  badgeText: String? = null,
  isActive: Boolean = false,
  onClick: () -> Unit
) {
  Box(contentAlignment = Alignment.BottomCenter) {
    IconButton(
      onClick = onClick,
      modifier = Modifier
        .size(48.dp)
        .clip(CircleShape)
        .background(if (isActive) Color(0xD90284C7) else Color(0x991E293B))
        .border(1.5.dp, if (isActive) Color(0xFFBAE6FD) else Color(0x88FFFFFF), CircleShape)
        .testTag(testTag)
    ) {
      Icon(
        imageVector = icon,
        contentDescription = contentDescription,
        tint = Color.White,
        modifier = Modifier.size(22.dp)
      )
    }
    if (badgeText != null) {
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xFFF59E0B))
          .padding(horizontal = 4.dp, vertical = 1.dp)
      ) {
        Text(
          text = badgeText,
          color = Color.Black,
          fontSize = 9.sp,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }
  }
}

@Composable
private fun BottomBridgeHud(
  uiState: BridgeGameUiState,
  onSnapToLane: (Lane) -> Unit,
  modifier: Modifier = Modifier
) {
  val currentLane = when {
    uiState.playerX < 0.28f -> Lane.LEFT
    uiState.playerX > 0.72f -> Lane.RIGHT
    else -> Lane.CENTER
  }

  Column(
    modifier = modifier,
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      LaneQuickPill(
        label = "🌿 Левый X${uiState.leftGateMultiplier}",
        isSelected = currentLane == Lane.LEFT,
        activeColor = Color(0xFF0284C7),
        testTag = "lane_left_button",
        onClick = { onSnapToLane(Lane.LEFT) },
        modifier = Modifier.weight(1f)
      )
      LaneQuickPill(
        label = "🧟 Центр (${uiState.zombies.size})",
        isSelected = currentLane == Lane.CENTER,
        activeColor = Color(0xFFEA580C),
        testTag = "lane_center_button",
        onClick = { onSnapToLane(Lane.CENTER) },
        modifier = Modifier.weight(1.25f)
      )
      LaneQuickPill(
        label = "🔥 Правый X${uiState.rightGateMultiplier}",
        isSelected = currentLane == Lane.RIGHT,
        activeColor = Color(0xFF06B6D4),
        testTag = "lane_right_button",
        onClick = { onSnapToLane(Lane.RIGHT) },
        modifier = Modifier.weight(1f)
      )
    }

    val hpFraction by animateFloatAsState(
      targetValue = (uiState.baseHp.toFloat() / uiState.maxBaseHp.toFloat()).coerceIn(0f, 1f),
      label = "baseHpFraction"
    )

    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(26.dp)
        .clip(RoundedCornerShape(6.dp))
        .background(Color(0xFF1E293B))
        .border(2.5.dp, Color.Black, RoundedCornerShape(6.dp))
        .testTag("base_hp_bar")
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth(hpFraction)
          .fillMaxHeight()
          .background(
            Brush.verticalGradient(
              colors = if (hpFraction > 0.35f) {
                listOf(Color(0xFF86EFAC), Color(0xFF22C55E), Color(0xFF16A34A))
              } else {
                listOf(Color(0xFFFCA5A5), Color(0xFFEF4444), Color(0xFFB91C1C))
              }
            )
          )
      )
      Text(
        text = "БАЗА: ${uiState.baseHp}/${uiState.maxBaseHp} HP  •  ОТРЯД: ${uiState.squadCount}/5  •  СТВОЛЫ: ${uiState.bulletStreams}/4",
        color = Color.White,
        fontSize = 11.sp,
        fontWeight = FontWeight.ExtraBold,
        style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 4f)),
        modifier = Modifier.align(Alignment.Center)
      )
    }
  }
}

@Composable
private fun LaneQuickPill(
  label: String,
  isSelected: Boolean,
  activeColor: Color,
  testTag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .height(48.dp)
      .clip(RoundedCornerShape(14.dp))
      .background(if (isSelected) activeColor else Color(0xB31E293B))
      .border(
        width = if (isSelected) 2.dp else 1.dp,
        color = if (isSelected) Color.White else Color(0x66FFFFFF),
        shape = RoundedCornerShape(14.dp)
      )
      .clickable(onClick = onClick)
      .testTag(testTag),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      color = Color.White,
      fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
      fontSize = 12.sp,
      textAlign = TextAlign.Center
    )
  }
}
