package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BridgeSkyBlue = Color(0xFF0284C7)
val BridgeCyanGlow = Color(0xFF06B6D4)
val BridgeAmberGold = Color(0xFFF59E0B)
val BridgeGrassGreen = Color(0xFF22C55E)
val BridgeDarkSlate = Color(0xFF0F172A)
val BridgeSurfaceSlate = Color(0xFF1E293B)
