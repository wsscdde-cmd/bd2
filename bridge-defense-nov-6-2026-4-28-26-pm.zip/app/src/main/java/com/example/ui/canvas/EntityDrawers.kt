package com.example.ui.canvas

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.example.model.ActiveTurret
import com.example.model.LeftBarrel
import com.example.model.PlantType
import com.example.model.RightBarrel
import com.example.model.UpgradeType
import com.example.model.Zombie
import com.example.model.ZombieType
import kotlin.math.sin

object EntityDrawers {

  private val strokeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.STROKE
    textAlign = Paint.Align.CENTER
    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    strokeJoin = Paint.Join.ROUND
    strokeCap = Paint.Cap.ROUND
  }

  private val fillTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.FILL
    textAlign = Paint.Align.CENTER
    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
  }

  fun DrawScope.drawOutlinedText(
    text: String,
    x: Float,
    y: Float,
    textSizePx: Float,
    fillColor: Int = android.graphics.Color.WHITE,
    strokeColor: Int = android.graphics.Color.BLACK,
    strokeWidthPx: Float = textSizePx * 0.22f
  ) {
    strokeTextPaint.textSize = textSizePx
    strokeTextPaint.color = strokeColor
    strokeTextPaint.strokeWidth = strokeWidthPx

    fillTextPaint.textSize = textSizePx
    fillTextPaint.color = fillColor

    drawContext.canvas.nativeCanvas.apply {
      drawText(text, x, y, strokeTextPaint)
      drawText(text, x, y, fillTextPaint)
    }
  }

  fun DrawScope.drawZombie(zombie: Zombie, canvasW: Float, canvasH: Float) {
    val cx = zombie.x * canvasW
    val cy = zombie.y * canvasH
    val baseUnit = canvasW * 0.072f * zombie.type.scale
    val bobY = sin(zombie.walkPhase) * (baseUnit * 0.08f)

    // Special Aura for Necro Shaman & Toxic Mutant
    if (zombie.type == ZombieType.NECRO_SHAMAN) {
      drawCircle(
        color = Color(0x44A855F7),
        radius = baseUnit * 0.72f,
        center = Offset(cx, cy)
      )
    } else if (zombie.type == ZombieType.TOXIC_MUTANT) {
      drawCircle(
        color = Color(0x444ADE80),
        radius = baseUnit * 0.65f,
        center = Offset(cx, cy)
      )
    }

    // Shadow under feet
    drawOval(
      color = Color(0x44000000),
      topLeft = Offset(cx - baseUnit * 0.42f, cy + baseUnit * 0.55f),
      size = Size(baseUnit * 0.84f, baseUnit * 0.26f)
    )

    // Legs / Dark pants
    val leftFootBob = sin(zombie.walkPhase) * (baseUnit * 0.06f)
    val rightFootBob = -leftFootBob
    drawRoundRect(
      color = Color(0xFF334155),
      topLeft = Offset(cx - baseUnit * 0.28f, cy + baseUnit * 0.28f + leftFootBob),
      size = Size(baseUnit * 0.23f, baseUnit * 0.34f),
      cornerRadius = CornerRadius(baseUnit * 0.08f)
    )
    drawRoundRect(
      color = Color(0xFF334155),
      topLeft = Offset(cx + baseUnit * 0.05f, cy + baseUnit * 0.28f + rightFootBob),
      size = Size(baseUnit * 0.23f, baseUnit * 0.34f),
      cornerRadius = CornerRadius(baseUnit * 0.08f)
    )

    // Body color by zombie type
    val shirtColor = when {
      zombie.hitFlash > 0.2f -> Color.White
      zombie.slowTimer > 0f -> Color(0xFF38BDF8)
      zombie.type == ZombieType.BOSS -> Color(0xFF991B1B)
      zombie.type == ZombieType.CYBER_JUGGERNAUT -> Color(0xFF475569)
      zombie.type == ZombieType.NECRO_SHAMAN -> Color(0xFF6B21A8)
      zombie.type == ZombieType.TOXIC_MUTANT -> Color(0xFF16A34A)
      zombie.type == ZombieType.SHIELD_BRUTE -> Color(0xFF1D4ED8)
      zombie.type == ZombieType.SPRINTER -> Color(0xFFDC2626)
      else -> Color(0xFFEA580C)
    }
    val bodyTop = cy - baseUnit * 0.08f + bobY
    val bodyW = baseUnit * 0.72f
    val bodyH = baseUnit * 0.48f
    drawRoundRect(
      color = shirtColor,
      topLeft = Offset(cx - bodyW / 2f, bodyTop),
      size = Size(bodyW, bodyH),
      cornerRadius = CornerRadius(baseUnit * 0.18f)
    )
    drawRoundRect(
      color = Color(0xFF1E293B),
      topLeft = Offset(cx - bodyW / 2f, bodyTop),
      size = Size(bodyW, bodyH),
      cornerRadius = CornerRadius(baseUnit * 0.18f),
      style = Stroke(width = 2.5f)
    )

    // Yellow zigzag sweater stripe across waist
    val zigY = bodyTop + bodyH * 0.72f
    drawLine(
      color = Color(0xFFFDE047),
      start = Offset(cx - bodyW * 0.38f, zigY),
      end = Offset(cx + bodyW * 0.38f, zigY),
      strokeWidth = 3f
    )

    // Zombie Head
    val headCenterY = cy - baseUnit * 0.32f + bobY
    val headRadius = baseUnit * 0.39f
    val skinColor = when {
      zombie.hitFlash > 0.2f -> Color.White
      zombie.slowTimer > 0f -> Color(0xFF7DD3FC)
      zombie.type == ZombieType.TOXIC_MUTANT -> Color(0xFF4ADE80)
      zombie.type == ZombieType.CYBER_JUGGERNAUT -> Color(0xFF94A3B8)
      else -> Color(0xFF84A955)
    }

    drawCircle(
      color = skinColor,
      radius = headRadius,
      center = Offset(cx, headCenterY)
    )
    drawCircle(
      color = Color(0xFF263818),
      radius = headRadius,
      center = Offset(cx, headCenterY),
      style = Stroke(width = 2.5f)
    )

    // Dark messy hair / cap on top of head
    drawArc(
      color = if (zombie.type == ZombieType.NECRO_SHAMAN) Color(0xFF581C87) else Color(0xFF273620),
      startAngle = 190f,
      sweepAngle = 160f,
      useCenter = true,
      topLeft = Offset(cx - headRadius, headCenterY - headRadius * 1.04f),
      size = Size(headRadius * 2f, headRadius * 1.3f)
    )

    // Type-specific headgear / shields
    if (zombie.type == ZombieType.CONEHEAD) {
      val conePath = Path().apply {
        moveTo(cx, headCenterY - headRadius * 1.65f)
        lineTo(cx - headRadius * 0.75f, headCenterY - headRadius * 0.45f)
        lineTo(cx + headRadius * 0.75f, headCenterY - headRadius * 0.45f)
        close()
      }
      drawPath(conePath, color = Color(0xFFF97316))
      drawPath(conePath, color = Color.Black, style = Stroke(width = 2.5f))
    } else if (zombie.type == ZombieType.SHIELD_BRUTE) {
      // Heavy Steel Riot Shield in front of body!
      drawRoundRect(
        color = Color(0xFF64748B),
        topLeft = Offset(cx - bodyW * 0.55f, bodyTop - baseUnit * 0.04f),
        size = Size(bodyW * 1.10f, bodyH * 1.12f),
        cornerRadius = CornerRadius(6f)
      )
      drawRoundRect(
        color = Color(0xFFCBD5E1),
        topLeft = Offset(cx - bodyW * 0.42f, bodyTop + bodyH * 0.12f),
        size = Size(bodyW * 0.84f, bodyH * 0.25f),
        cornerRadius = CornerRadius(4f)
      )
      drawRoundRect(
        color = Color(0xFF0F172A),
        topLeft = Offset(cx - bodyW * 0.55f, bodyTop - baseUnit * 0.04f),
        size = Size(bodyW * 1.10f, bodyH * 1.12f),
        cornerRadius = CornerRadius(6f),
        style = Stroke(width = 2.5f)
      )
    }

    // Crazy Zombie Eyes (or glowing red visor for Cyber Juggernaut)
    val eyeY = headCenterY - headRadius * 0.08f
    if (zombie.type == ZombieType.CYBER_JUGGERNAUT) {
      drawRoundRect(
        color = Color(0xFFEF4444),
        topLeft = Offset(cx - headRadius * 0.65f, eyeY - headRadius * 0.16f),
        size = Size(headRadius * 1.30f, headRadius * 0.32f),
        cornerRadius = CornerRadius(4f)
      )
    } else {
      val leftEyeX = cx - headRadius * 0.34f
      val rightEyeX = cx + headRadius * 0.34f
      drawCircle(color = Color.White, radius = headRadius * 0.24f, center = Offset(leftEyeX, eyeY))
      drawCircle(color = Color.White, radius = headRadius * 0.21f, center = Offset(rightEyeX, eyeY))
      drawCircle(color = Color(0xFF1E293B), radius = headRadius * 0.10f, center = Offset(leftEyeX, eyeY))
      drawCircle(color = Color(0xFF1E293B), radius = headRadius * 0.09f, center = Offset(rightEyeX, eyeY))
    }

    // Open mouth
    drawRoundRect(
      color = Color(0xFF7F1D1D),
      topLeft = Offset(cx - headRadius * 0.28f, headCenterY + headRadius * 0.24f),
      size = Size(headRadius * 0.56f, headRadius * 0.26f),
      cornerRadius = CornerRadius(headRadius * 0.1f)
    )

    // HP Bar above Bosses and damaged Elite enemies
    val isEliteOrBoss = zombie.type != ZombieType.NORMAL && zombie.type != ZombieType.SPRINTER
    if (zombie.type == ZombieType.BOSS || (isEliteOrBoss && zombie.hp < zombie.maxHp)) {
      val barW = baseUnit * (if (zombie.type == ZombieType.BOSS) 1.15f else 0.85f)
      val barH = if (zombie.type == ZombieType.BOSS) 10f else 6f
      val hpRatio = (zombie.hp.toFloat() / zombie.maxHp.toFloat()).coerceIn(0f, 1f)
      drawRoundRect(
        color = Color(0xAA000000),
        topLeft = Offset(cx - barW / 2f, headCenterY - headRadius * 1.45f),
        size = Size(barW, barH),
        cornerRadius = CornerRadius(4f)
      )
      drawRoundRect(
        color = if (zombie.type == ZombieType.BOSS) Color(0xFFEF4444) else Color(0xFFFACC15),
        topLeft = Offset(cx - barW / 2f + 1.5f, headCenterY - headRadius * 1.45f + 1.5f),
        size = Size((barW - 3f) * hpRatio, barH - 3f),
        cornerRadius = CornerRadius(3f)
      )
    }
  }

  fun DrawScope.drawBlueBarrel(
    centerX: Float,
    centerY: Float,
    barrelW: Float,
    barrelH: Float,
    hpText: String,
    hitFlash: Float
  ) {
    val scale = 1f + hitFlash * 0.08f
    val w = barrelW * scale
    val h = barrelH * scale
    val left = centerX - w / 2f
    val top = centerY - h / 2f

    drawRoundRect(
      color = Color(0xFF3B82F6),
      topLeft = Offset(left - w * 0.10f, centerY - h * 0.24f),
      size = Size(w * 0.14f, h * 0.48f),
      cornerRadius = CornerRadius(6f)
    )

    val barrelBrush = Brush.verticalGradient(
      colors = if (hitFlash > 0.3f) {
        listOf(Color.White, Color(0xFFBAE6FD), Color(0xFF60A5FA))
      } else {
        listOf(Color(0xFF93C5FD), Color(0xFF60A5FA), Color(0xFF2563EB))
      },
      startY = top,
      endY = top + h
    )
    drawRoundRect(
      brush = barrelBrush,
      topLeft = Offset(left, top),
      size = Size(w, h),
      cornerRadius = CornerRadius(h * 0.26f)
    )

    drawRoundRect(
      color = Color(0x55FFFFFF),
      topLeft = Offset(left + w * 0.08f, top + h * 0.10f),
      size = Size(w * 0.84f, h * 0.22f),
      cornerRadius = CornerRadius(h * 0.12f)
    )

    drawRoundRect(
      color = Color(0xFF1E3A8A),
      topLeft = Offset(left, top),
      size = Size(w, h),
      cornerRadius = CornerRadius(h * 0.26f),
      style = Stroke(width = 3f)
    )

    val fontSize = h * 0.56f
    drawOutlinedText(
      text = hpText,
      x = centerX,
      y = centerY + fontSize * 0.35f,
      textSizePx = fontSize
    )
  }

  fun DrawScope.drawLeftBarrelWithPlant(
    barrel: LeftBarrel,
    canvasW: Float,
    canvasH: Float
  ) {
    val cx = 0.135f * canvasW
    val cy = barrel.y * canvasH
    val barrelW = canvasW * 0.20f
    val barrelH = canvasH * 0.064f

    val badgeCenterY = cy - barrelH * 0.82f
    val badgeRadius = barrelW * 0.34f
    drawPlantIconBadge(
      plantType = barrel.plantType,
      cx = cx,
      cy = badgeCenterY,
      radius = badgeRadius
    )

    drawBlueBarrel(
      centerX = cx,
      centerY = cy,
      barrelW = barrelW,
      barrelH = barrelH,
      hpText = barrel.hp.toString(),
      hitFlash = barrel.hitFlash
    )
  }

  fun DrawScope.drawPlantIconBadge(
    plantType: PlantType,
    cx: Float,
    cy: Float,
    radius: Float,
    levelBadge: Int? = null
  ) {
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFFFEF08A), Color(0xFFFACC15), Color(0xFFEAB308)),
        center = Offset(cx, cy),
        radius = radius
      ),
      radius = radius,
      center = Offset(cx, cy)
    )
    drawCircle(
      color = Color(0xFFFEF9C3),
      radius = radius,
      center = Offset(cx, cy),
      style = Stroke(width = 3.5f)
    )

    val potW = radius * 0.75f
    val potH = radius * 0.45f
    val potTop = cy + radius * 0.25f
    drawRoundRect(
      color = Color(0xFFC2410C),
      topLeft = Offset(cx - potW / 2f, potTop),
      size = Size(potW, potH),
      cornerRadius = CornerRadius(6f)
    )
    drawRoundRect(
      color = Color(0xFF7C2D12),
      topLeft = Offset(cx - potW * 0.56f, potTop),
      size = Size(potW * 1.12f, potH * 0.32f),
      cornerRadius = CornerRadius(4f)
    )

    when (plantType) {
      PlantType.SPIDER_SHOOTER -> {
        for (dir in listOf(-1f, 1f)) {
          drawArc(
            color = Color(0xFF84CC16),
            startAngle = if (dir < 0) 140f else 280f,
            sweepAngle = 100f,
            useCenter = false,
            topLeft = Offset(cx + dir * radius * 0.15f - radius * 0.5f, cy - radius * 0.55f),
            size = Size(radius, radius * 0.9f),
            style = Stroke(width = radius * 0.18f)
          )
        }
        drawCircle(
          color = Color(0xFF4ADE80),
          radius = radius * 0.42f,
          center = Offset(cx, cy - radius * 0.14f)
        )
        drawCircle(color = Color.White, radius = radius * 0.13f, center = Offset(cx - radius * 0.15f, cy - radius * 0.18f))
        drawCircle(color = Color.White, radius = radius * 0.13f, center = Offset(cx + radius * 0.15f, cy - radius * 0.18f))
        drawCircle(color = Color.Black, radius = radius * 0.07f, center = Offset(cx - radius * 0.15f, cy - radius * 0.18f))
        drawCircle(color = Color.Black, radius = radius * 0.07f, center = Offset(cx + radius * 0.15f, cy - radius * 0.18f))
      }

      PlantType.EGGPLANT_MORTAR -> {
        drawOval(
          color = Color(0xFF9333EA),
          topLeft = Offset(cx - radius * 0.44f, cy - radius * 0.65f),
          size = Size(radius * 0.88f, radius * 0.96f)
        )
        drawOval(
          color = Color(0xFF3B0764),
          topLeft = Offset(cx - radius * 0.44f, cy - radius * 0.65f),
          size = Size(radius * 0.88f, radius * 0.96f),
          style = Stroke(width = 3f)
        )
        drawOval(
          color = Color(0xFF22C55E),
          topLeft = Offset(cx - radius * 0.36f, cy - radius * 0.78f),
          size = Size(radius * 0.72f, radius * 0.32f)
        )
        drawCircle(color = Color.White, radius = radius * 0.11f, center = Offset(cx - radius * 0.15f, cy - radius * 0.32f))
        drawCircle(color = Color.White, radius = radius * 0.11f, center = Offset(cx + radius * 0.15f, cy - radius * 0.32f))
      }

      PlantType.ANGRY_FLOWER -> {
        for (i in 0 until 8) {
          val angle = i * (Math.PI / 4.0)
          val px = cx + kotlin.math.cos(angle).toFloat() * radius * 0.42f
          val py = (cy - radius * 0.18f) + sin(angle).toFloat() * radius * 0.42f
          drawCircle(color = Color.White, radius = radius * 0.22f, center = Offset(px, py))
        }
        drawCircle(color = Color(0xFFF97316), radius = radius * 0.34f, center = Offset(cx, cy - radius * 0.18f))
        drawCircle(color = Color.White, radius = radius * 0.12f, center = Offset(cx - radius * 0.13f, cy - radius * 0.22f))
        drawCircle(color = Color.White, radius = radius * 0.12f, center = Offset(cx + radius * 0.13f, cy - radius * 0.22f))
        drawCircle(color = Color.Black, radius = radius * 0.06f, center = Offset(cx - radius * 0.13f, cy - radius * 0.22f))
        drawCircle(color = Color.Black, radius = radius * 0.06f, center = Offset(cx + radius * 0.13f, cy - radius * 0.22f))
      }

      PlantType.FROST_CACTUS -> {
        drawCircle(color = Color(0xFF0284C7), radius = radius * 0.44f, center = Offset(cx, cy - radius * 0.18f))
        drawCircle(color = Color(0xFFBAE6FD), radius = radius * 0.28f, center = Offset(cx, cy - radius * 0.18f))
      }
    }

    if (levelBadge != null) {
      drawOutlinedText(
        text = "Lv.$levelBadge",
        x = cx,
        y = cy + radius * 0.85f,
        textSizePx = radius * 0.48f,
        fillColor = android.graphics.Color.rgb(134, 239, 172)
      )
    }
  }

  fun DrawScope.drawActiveTurret(
    turret: ActiveTurret,
    canvasW: Float,
    canvasH: Float
  ) {
    val cx = 0.255f * canvasW + turret.recoilAnim * 6f
    val cy = turret.y * canvasH
    val radius = canvasW * 0.056f
    drawPlantIconBadge(
      plantType = turret.plantType,
      cx = cx,
      cy = cy,
      radius = radius,
      levelBadge = turret.level
    )
  }

  fun DrawScope.drawRightBarrelWithUpgrade(
    barrel: RightBarrel,
    canvasW: Float,
    canvasH: Float
  ) {
    val cx = 0.865f * canvasW
    val cy = barrel.y * canvasH
    val barrelW = canvasW * 0.20f
    val barrelH = canvasH * 0.058f

    val badgeCenterY = cy - barrelH * 0.86f
    val badgeRadius = barrelW * 0.33f

    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFFFEF08A), Color(0xFFFACC15), Color(0xFFD97706)),
        center = Offset(cx, badgeCenterY),
        radius = badgeRadius
      ),
      radius = badgeRadius,
      center = Offset(cx, badgeCenterY)
    )
    drawCircle(
      color = Color(0xFFFEF9C3),
      radius = badgeRadius,
      center = Offset(cx, badgeCenterY),
      style = Stroke(width = 3f)
    )

    when (barrel.upgradeType) {
      UpgradeType.FIRE_RATE_BOOST, UpgradeType.ATTACK_BOOST -> {
        val burstColor = if (barrel.upgradeType == UpgradeType.ATTACK_BOOST) Color(0xFFDC2626) else Color(0xFFF97316)
        drawCircle(color = burstColor, radius = badgeRadius * 0.65f, center = Offset(cx, badgeCenterY))
        val bladePath = Path().apply {
          moveTo(cx + badgeRadius * 0.45f, badgeCenterY - badgeRadius * 0.45f)
          lineTo(cx + badgeRadius * 0.15f, badgeCenterY - badgeRadius * 0.40f)
          lineTo(cx - badgeRadius * 0.35f, badgeCenterY + badgeRadius * 0.15f)
          lineTo(cx - badgeRadius * 0.15f, badgeCenterY + badgeRadius * 0.35f)
          lineTo(cx + badgeRadius * 0.40f, badgeCenterY - badgeRadius * 0.15f)
          close()
        }
        drawPath(bladePath, color = Color(0xFFE2E8F0))
        drawPath(bladePath, color = Color.Black, style = Stroke(width = 2.5f))
      }

      UpgradeType.BULLETS_PLUS_1 -> {
        drawRoundRect(
          color = Color(0xFFF59E0B),
          topLeft = Offset(cx - badgeRadius * 0.28f, badgeCenterY - badgeRadius * 0.15f),
          size = Size(badgeRadius * 0.56f, badgeRadius * 0.55f),
          cornerRadius = CornerRadius(8f)
        )
        drawArc(
          color = Color(0xFF2563EB),
          startAngle = 180f,
          sweepAngle = 180f,
          useCenter = true,
          topLeft = Offset(cx - badgeRadius * 0.28f, badgeCenterY - badgeRadius * 0.55f),
          size = Size(badgeRadius * 0.56f, badgeRadius * 0.75f)
        )
      }

      UpgradeType.HERO_PLUS_1 -> {
        drawOval(
          color = Color(0xFFA16236),
          topLeft = Offset(cx - badgeRadius * 0.52f, badgeCenterY - badgeRadius * 0.32f),
          size = Size(badgeRadius * 1.04f, badgeRadius * 0.72f)
        )
        drawOval(
          color = Color(0xFFD97706),
          topLeft = Offset(cx - badgeRadius * 0.72f, badgeCenterY - badgeRadius * 0.48f),
          size = Size(badgeRadius * 1.44f, badgeRadius * 0.32f)
        )
        drawRoundRect(
          color = Color(0xFFB45309),
          topLeft = Offset(cx - badgeRadius * 0.40f, badgeCenterY - badgeRadius * 0.76f),
          size = Size(badgeRadius * 0.80f, badgeRadius * 0.38f),
          cornerRadius = CornerRadius(6f)
        )
      }
    }

    drawBlueBarrel(
      centerX = cx,
      centerY = cy,
      barrelW = barrelW,
      barrelH = barrelH,
      hpText = barrel.hp.toString(),
      hitFlash = barrel.hitFlash
    )

    val labelText = when (barrel.upgradeType) {
      UpgradeType.ATTACK_BOOST -> "Урон +${barrel.bonusAmount}%"
      UpgradeType.BULLETS_PLUS_1 -> "Снаряды +1"
      UpgradeType.FIRE_RATE_BOOST -> "Темп +14%"
      UpgradeType.HERO_PLUS_1 -> "Герой +1"
    }
    drawOutlinedText(
      text = labelText,
      x = cx,
      y = cy - barrelH * 0.34f,
      textSizePx = barrelH * 0.38f,
      fillColor = android.graphics.Color.WHITE
    )
  }

  fun DrawScope.drawCapybaraCrocodileSquad(
    playerX: Float,
    squadCount: Int,
    muzzleFlash: Float,
    canvasW: Float,
    canvasH: Float
  ) {
    val baseCenterX = playerX * canvasW
    val baseCenterY = 0.745f * canvasH
    val unitSize = canvasW * 0.135f

    val visibleCount = squadCount.coerceIn(1, 5)
    val offsets = listOf(
      Offset(0.0f, -0.18f),
      Offset(-0.42f, 0.14f),
      Offset(0.42f, 0.14f),
      Offset(-0.22f, -0.34f),
      Offset(0.22f, -0.34f)
    )

    for (i in (visibleCount - 1) downTo 0) {
      val off = offsets[i]
      val ux = (baseCenterX + off.x * unitSize).coerceIn(unitSize * 0.45f, canvasW - unitSize * 0.45f)
      val uy = baseCenterY + off.y * unitSize
      drawSingleCapybaraOnCrocodile(
        cx = ux,
        cy = uy,
        unitSize = unitSize * (if (i == 0) 1.08f else 0.92f),
        muzzleFlash = muzzleFlash
      )
    }
  }

  private fun DrawScope.drawSingleCapybaraOnCrocodile(
    cx: Float,
    cy: Float,
    unitSize: Float,
    muzzleFlash: Float
  ) {
    drawOval(
      color = Color(0x44000000),
      topLeft = Offset(cx - unitSize * 0.48f, cy + unitSize * 0.26f),
      size = Size(unitSize * 0.96f, unitSize * 0.24f)
    )

    drawRoundRect(
      color = Color(0xFF65A30D),
      topLeft = Offset(cx - unitSize * 0.45f, cy + unitSize * 0.02f),
      size = Size(unitSize * 0.90f, unitSize * 0.36f),
      cornerRadius = CornerRadius(unitSize * 0.16f)
    )
    drawRoundRect(
      color = Color(0xFF365314),
      topLeft = Offset(cx - unitSize * 0.45f, cy + unitSize * 0.02f),
      size = Size(unitSize * 0.90f, unitSize * 0.36f),
      cornerRadius = CornerRadius(unitSize * 0.16f),
      style = Stroke(width = 3f)
    )
    drawRoundRect(
      color = Color(0xFFECFCCB),
      topLeft = Offset(cx - unitSize * 0.35f, cy + unitSize * 0.22f),
      size = Size(unitSize * 0.70f, unitSize * 0.12f),
      cornerRadius = CornerRadius(6f)
    )

    val capyW = unitSize * 0.52f
    val capyH = unitSize * 0.48f
    val capyTop = cy - unitSize * 0.36f
    drawOval(
      color = Color(0xFF9A5B32),
      topLeft = Offset(cx - capyW / 2f, capyTop),
      size = Size(capyW, capyH)
    )
    drawOval(
      color = Color(0xFF431407),
      topLeft = Offset(cx - capyW / 2f, capyTop),
      size = Size(capyW, capyH),
      style = Stroke(width = 2.5f)
    )

    drawRoundRect(
      color = Color(0xFFDC2626),
      topLeft = Offset(cx - capyW * 0.44f, cy - unitSize * 0.02f),
      size = Size(capyW * 0.88f, unitSize * 0.13f),
      cornerRadius = CornerRadius(6f)
    )

    drawOval(
      color = Color(0xFFB45309),
      topLeft = Offset(cx - capyW * 0.72f, capyTop - unitSize * 0.06f),
      size = Size(capyW * 1.44f, unitSize * 0.18f)
    )
    drawOval(
      color = Color(0xFF451A03),
      topLeft = Offset(cx - capyW * 0.72f, capyTop - unitSize * 0.06f),
      size = Size(capyW * 1.44f, unitSize * 0.18f),
      style = Stroke(width = 2.5f)
    )
    drawRoundRect(
      color = Color(0xFF92400E),
      topLeft = Offset(cx - capyW * 0.42f, capyTop - unitSize * 0.22f),
      size = Size(capyW * 0.84f, unitSize * 0.18f),
      cornerRadius = CornerRadius(8f)
    )

    val gunX = cx + unitSize * 0.24f
    val gunTop = cy - unitSize * 0.42f
    val gunW = unitSize * 0.22f
    val gunH = unitSize * 0.46f
    drawRoundRect(
      color = Color(0xFF1E293B),
      topLeft = Offset(gunX, gunTop),
      size = Size(gunW, gunH),
      cornerRadius = CornerRadius(4f)
    )
    drawRoundRect(
      color = Color(0xFF64748B),
      topLeft = Offset(gunX + gunW * 0.2f, gunTop + 4f),
      size = Size(gunW * 0.6f, gunH * 0.5f),
      cornerRadius = CornerRadius(2f)
    )

    if (muzzleFlash > 0.1f) {
      val flashR = unitSize * 0.24f * muzzleFlash
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(Color.White, Color(0xFFFDE047), Color(0x00F97316)),
          center = Offset(gunX + gunW / 2f, gunTop - flashR * 0.3f),
          radius = flashR
        ),
        radius = flashR,
        center = Offset(gunX + gunW / 2f, gunTop - flashR * 0.3f)
      )
    }
  }
}
